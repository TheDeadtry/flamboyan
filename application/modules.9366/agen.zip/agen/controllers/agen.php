<?php if (!defined('BASEPATH')) exit('Maaf, akses secara langsung tidak diperkenankan.');

class Agen extends MX_Controller{
	public function __construct(){
            parent::__construct();
			$this->load->model('M_session');			
			$this->load->model('M_agen');			
	}
	
	function index(){
	$session = $this->M_session->get_session();
		if (!$session['session_userid'] && !$session['session_status']){
			//user belum login
			$data['namamodule'] = "login";
			$data['namafileview'] = "login";
			echo Modules::run('template/login_template', $data);
		}
		else{
		$id_user = $session['session_userid'];
		$status = $session['session_status'];
			//user sudah login
			if ($id_user && $status==1){
			//user sudah login

				$data['tampil_data_agen'] = $this->M_agen->tampil_data_agen();
				$data['tampil_data_group'] = $this->M_agen->tampil_data_group();


				$data['namamodule'] = "agen";
				$data['namafileview'] = "agenadmin";
				echo Modules::run('template/admin_template', $data);
			}
			else if ($id_user && $status==2){
				
				$data['namamodule'] = "agen";
				$data['namafileview'] = "agenagen";
				echo Modules::run('template/agen_template', $data); 
			}
		
		}
		 
	}

	function simpan_data_agen(){
		// $player = array();
		// $player=$this->input->post('daerah');
		// echo "".sizeof($player);
		$kode	= $this->input->post('kode');
		$nama	= $this->input->post('nama');
		$namamandarin	= $this->input->post('namamandarin');
		$notel	= $this->input->post('notel');
		$nofax	= $this->input->post('nofax');
		$direktur	= $this->input->post('direktur');
		$nosiup	= $this->input->post('nosiup');
		$hp	= $this->input->post('hp');
		$email	= $this->input->post('email');
		$alamat	= $this->input->post('alamat');
		$alamatmandarin	= $this->input->post('alamatmandarin');
		$status	= $this->input->post('status');
		$group	= $this->input->post('group');
		$berlaku	= $this->input->post('berlaku');
		$selesai	= $this->input->post('selesai');
		$username	= $this->input->post('username');
		$password	= $this->input->post('password');
		
		$this->M_agen->simpan_data_agen($kode, $nama,$namamandarin,$notel,$nofax,$direktur,$nosiup, $hp, $email,$alamatmandarin,$alamat,$status,$group,$berlaku,$selesai,$username,$password);

		redirect('agen');
	}

		function simpan_data_group(){
		// $player = array();
		// $player=$this->input->post('daerah');
		// echo "".sizeof($player);
		$kode	= $this->input->post('kode');
		$nama	= $this->input->post('nama');
		$hp	= $this->input->post('hp');
		$email	= $this->input->post('email');
		$alamat	= $this->input->post('alamat');
		$username= $this->input->post('username');
		$password= $this->input->post('password');

		
		$this->M_agen->simpan_data_group($kode, $nama, $hp, $email,$alamat,$username,$password);

		redirect('agen');
	}

function update_group() {
		$this->M_agen->update_group();
		redirect('agen');
	}

	function hapus_group() {
		$this->M_agen->hapus_group();
		redirect('agen');
	}

	function update_agen() {
		$this->M_agen->update_agen();
		redirect('agen');
	}

		function hapus_agen() {
		$this->M_agen->hapus_agen();
		redirect('agen');
	}
	
}