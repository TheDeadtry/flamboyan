<?php
class M_agen extends CI_Model{
    function __construct(){
        parent::__construct();
    }


 function simpan_data_agen($kode, $nama,$namamandarin,$notel,$nofax,$direktur,$nosiup, $hp, $email,$alamatmandarin,$alamat,$status,$group,$berlaku,$selesai,$username,$password){

		$data = array (
			'kode_agen'=>$kode, 
			'nama'=>$nama,
			'namamandarin'=>$namamandarin,
			'notel'=>$notel, 
			'nofax'=>$nofax, 
			'direktur'=>$direktur, 
			'nosiup'=>$nosiup, 
			'hp'=>$hp, 
			'email'=>$email, 
			'alamat'=>$alamat,
			'alamatmandarin'=>$alamatmandarin, 
			'kode_group'=>$group, 
			'berlaku'=>$berlaku, 
			'selesai'=>$selesai, 
			'username'=>$username, 
			'password'=>"5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8", 
			'status'=>"2", 
			);

		$this->db->insert('dataagen',$data);
	}

	 	function update_agen() {
		$id = $this->input->post('id_agen');
		$data = array(
				'kode_agen' => $this->input->post('kode'),
				'nama' => $this->input->post('nama'),
				'namamandarin' => $this->input->post('namamandarin'),
				'notel' => $this->input->post('notel'),
				'nofax' => $this->input->post('nofax'),
				'direktur' => $this->input->post('direktur'),
				'nosiup' => $this->input->post('nosiup'),
				'hp' => $this->input->post('hp'),
				'email' => $this->input->post('email'),
				'email' => $this->input->post('email'),
				'alamat' => $this->input->post('alamat'),
				'alamatmandarin' => $this->input->post('alamatmandarin'),
				'kode_group' => $this->input->post('kode_group'),
				'berlaku' => $this->input->post('berlaku'),
				'selesai' => $this->input->post('selesai'),
				'username' => $this->input->post('username'),

				'password'=>"5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8",  

			);
		$this->db->where('id_agen', $id);
		$this->db->update('dataagen', $data);
	}




	function tampil_data_agen(){
		$sql = "SELECT * FROM dataagen";
                $query = $this->db->query($sql);

            return $query->result();
	} 
		function tampil_data_group(){
		$sql = "SELECT * FROM datagroup";
                $query = $this->db->query($sql);

            return $query->result();
	} 
 
 	function update_group() {
		$id = $this->input->post('id_group');
		$data = array(
				'kode_group' => $this->input->post('kode'),
				'nama' => $this->input->post('nama'),
				'hp' => $this->input->post('hp'),
				'email' => $this->input->post('email'),
				'alamat' => $this->input->post('alamat'),
				'username' => $this->input->post('username'),
				'password'=>"5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8",  

			);
		$this->db->where('id_group', $id);
		$this->db->update('datagroup', $data);
	}

		 function simpan_data_group($kode, $nama, $hp, $email,$alamat,$user,$pass){

		$data = array (
			'kode_group'=>$kode, 
			'nama'=>$nama,
			'hp'=>$hp, 
			'email'=>$email, 
			'alamat'=>$alamat, 
			'username'=>$user, 
			'password'=>"5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8",  
			);

		$this->db->insert('datagroup',$data);
	}

	function hapus_group() {
		$id = $this->input->post('id_group');
		$this->db->where('id_group', $id);
		$this->db->delete('datagroup');
	}

	function hapus_agen() {
		$id = $this->input->post('id_agen');
		$this->db->where('id_agen', $id);
		$this->db->delete('dataagen');
	}

}
?>